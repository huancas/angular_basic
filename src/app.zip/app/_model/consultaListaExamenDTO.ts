import { Consulta } from "./consulta";
import { Examen } from "./examen";

export class ConsultaListaExamenDTO {
    consulta: Consulta;
    lstExamen: Examen[];
}